import { useState } from 'react';
import { useRouter } from 'next/router';

export default function Signup() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('tester');
  const [error, setError] = useState('');
  const router = useRouter();

  async function handleSubmit(e: any) {
    e.preventDefault();
    setError('');
    try {
      const res = await fetch('/api/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, password, role }),
      });
      if (res.ok) {
        router.push('/login');
      } else {
        const err = await res.json();
        setError(err.error || 'Signup failed');
      }
    } catch (err) {
      setError('Signup failed');
    }
  }

  return (
    <main className="flex flex-col items-center justify-center min-h-screen p-4">
      <h1 className="text-2xl font-bold mb-4">تسجيل حساب جديد</h1>
      {error && <p className="text-red-500 mb-2">{error}</p>}
      <form onSubmit={handleSubmit} className="flex flex-col space-y-2 w-full max-w-sm">
        <input
          type="text"
          placeholder="الاسم"
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="p-2 border"
          required
        />
        <input
          type="email"
          placeholder="البريد الإلكتروني"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="p-2 border"
          required
        />
        <input
          type="password"
          placeholder="كلمة المرور"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="p-2 border"
          required
        />
        <div className="flex space-x-2">
          <label className="flex items-center space-x-1">
            <input
              type="radio"
              name="role"
              value="tester"
              checked={role === 'tester'}
              onChange={(e) => setRole(e.target.value)}
            />
            <span>مجرّب / مؤثر</span>
          </label>
          <label className="flex items-center space-x-1">
            <input
              type="radio"
              name="role"
              value="business"
              checked={role === 'business'}
              onChange={(e) => setRole(e.target.value)}
            />
            <span>صاحب نشاط</span>
          </label>
        </div>
        <button type="submit" className="p-2 bg-blue-500 text-white">
          تسجيل
        </button>
      </form>
    </main>
  );
}