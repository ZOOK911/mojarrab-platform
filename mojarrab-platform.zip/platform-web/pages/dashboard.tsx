import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';

interface User {
  id: number;
  name: string;
  role: string;
}

export default function Dashboard() {
  const [user, setUser] = useState<User | null>(null);
  const [error, setError] = useState('');
  const router = useRouter();

  useEffect(() => {
    async function fetchMe() {
      try {
        const res = await fetch('/api/me');
        if (res.ok) {
          const data = await res.json();
          setUser(data.user);
        } else {
          router.push('/login');
        }
      } catch (err) {
        setError('حدث خطأ أثناء جلب البيانات');
      }
    }
    fetchMe();
  }, [router]);

  if (!user) {
    return (
      <main className="flex items-center justify-center min-h-screen">
        <p>جار التحميل...</p>
      </main>
    );
  }

  return (
    <main className="p-4">
      <h1 className="text-2xl font-bold mb-4">مرحباً {user.name}</h1>
      {user.role === 'tester' && (
        <section>
          <h2 className="text-xl font-semibold mb-2">لوحة المجرّب</h2>
          <p>هنا يمكنك استعراض الحملات المتاحة والتقديم عليها.</p>
        </section>
      )}
      {user.role === 'business' && (
        <section>
          <h2 className="text-xl font-semibold mb-2">لوحة صاحب النشاط</h2>
          <p>هنا يمكنك إنشاء الحملات ومتابعة المتقدمين.</p>
        </section>
      )}
      {user.role === 'admin' && (
        <section>
          <h2 className="text-xl font-semibold mb-2">لوحة المشرف</h2>
          <p>هنا يمكنك إدارة المستخدمين والحملات.</p>
        </section>
      )}
      {error && <p className="text-red-500 mt-4">{error}</p>}
    </main>
  );
}