# Mojarrab Platform (Web)

This repository contains a skeleton implementation of the **Mojarrab** platform as a web application.  The goal of this project is to provide a starting point for a real product‑testing and influencer‑matching platform targeting the Saudi market.  It is designed to be extended and integrated with real user data and real businesses.

## Features

The initial version includes:

- A Next.js project scaffold with TypeScript support.
- A Prisma schema defining the core data models for users, social accounts, business profiles, campaigns, applications, reviews and social posts.
- Environment configuration using an SQLite database (development only).
- Basic React pages for sign‑up, login and a placeholder dashboard.
- API routes to register new users and log in using a simple SHA‑256 password hash.

> **Important:**
> This project is a foundation and does not include authentication tokens, authorisation middleware, campaign management UIs or payment integration.  It is intentionally free of any fake or hard‑coded data.  All functionality depends on real data entered by users or returned from future integrations.  You should extend it with proper security, validation and business logic before deploying to production.

## Running Locally

1. Install dependencies (requires Node.js ≥ 18):

```bash
npm install
```

2. Initialise the Prisma database:

```bash
npx prisma generate
npx prisma migrate dev --name init
```

3. Start the development server:

```bash
npm run dev
```

The application will be available at `http://localhost:3000`.

## Contribution

Contributions are welcome.  Please fork this repository and open a pull request with your changes.  Remember to maintain the "no fake data" principle—use real data sources or user input for all functionality.
