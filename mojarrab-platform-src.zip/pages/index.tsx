import Link from 'next/link';

export default function Home() {
  return (
    <main className="flex flex-col items-center justify-center min-h-screen p-4">
      <h1 className="text-3xl font-bold mb-4">مرحبا في منصة مجرب</h1>
      <p className="mb-4">يمكنك تسجيل حساب كمجرب أو صاحب نشاط للبدء في استخدام المنصة.</p>
      <div className="flex space-x-4">
        <Link href="/signup" className="px-4 py-2 bg-blue-500 text-white rounded">تسجيل</Link>
        <Link href="/login" className="px-4 py-2 bg-gray-500 text-white rounded">دخول</Link>
      </div>
    </main>
  );
}